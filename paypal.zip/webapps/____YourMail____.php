<?php
$emailku = 'kmiofj@gmail.com';
?>
