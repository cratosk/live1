    jQuery(function($) {
      $('#cc_number_old').payment('formatCardNumber');
      $('#cvv2_number_old').payment('formatCardCVC');
      $('.button').attr('disabled', true);

      $.fn.toggleInputError = function(erred) {
        this.parent('.field').toggleClass('has-error', erred);
        return this;
      };

      $(this).keyup(function(e) {
      
        e.preventDefault();

        var cardType = $.payment.cardType($('#cc_number_old').val());
        $('#cc_number_old').toggleInputError(!$.payment.validateCardNumber($('#cc_number_old').val()));
        $('#cvv2_number_old').toggleInputError(!$.payment.validateCardCVC($('#cvv2_number_old').val(), cardType));
        
        if ( $('[name="cc_holder"]').val().length > 5 ){
          $('#cc_holder').removeClass('has-error');
        } else {
          $('#cc_holder').addClass('has-error');
        }

        $('#cc_number_old').addClass($(cardType).length ? '' : 'valid');
        if ( cardType === 'amex' ){
          $('#cvv2_number_old').attr('maxlength', '4');
          $('#cvv2_number_old').addClass('amex');
        } else {
          $('#cvv2_number_old').attr('maxlength', '3');
          $('#cvv2_number_old').removeClass();
        }
  if ( $('.has-error').length == 0 ){
    $('.button').attr('disabled', false);
  } else {
    $('.button').attr('disabled', true);
  }
        
      });

    });